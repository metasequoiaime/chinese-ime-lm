from pathlib import Path
import subprocess, shutil, hashlib, json
folder=Path('reference/target/safe-dot-evidence')
binary=Path('reference/target/release/deps/chinese_ime_lm-4e5346c28d9c73d2')
shutil.copy2(binary,folder/'red-binary')
paths=['reference/src/lib.rs','reference/Cargo.toml','reference/Cargo.lock']
originals={path:subprocess.check_output(['git','show','HEAD:'+path]) for path in paths}
(folder/'experimental.patch').write_bytes(subprocess.check_output(['git','diff','--',*paths]))
try:
    (folder/'probe.rs').write_bytes((folder/'candidate-probe.rs').read_bytes())
    with (folder/'candidate-build.log').open('w') as output:
        subprocess.run(['cargo','test','--manifest-path','reference/Cargo.toml','--release','--locked','--no-run'],stdout=output,stderr=subprocess.STDOUT,check=True)
    shutil.copy2(binary,folder/'candidate-binary')
finally:
    for path,raw in originals.items(): Path(path).write_bytes(raw)
info={name:hashlib.sha256((folder/name).read_bytes()).hexdigest() for name in ['red-binary','candidate-binary','red-probe.rs','candidate-probe.rs']}
info['restored']={path:hashlib.sha256(Path(path).read_bytes()).hexdigest() for path in paths}
assert all(Path(path).read_bytes()==raw for path,raw in originals.items())
(folder/'binaries.json').write_text(json.dumps(info,indent=2)+'\n')
