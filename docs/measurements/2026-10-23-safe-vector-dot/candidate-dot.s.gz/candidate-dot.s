
reference/target/safe-dot-evidence/candidate-binary:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100031980 <__RNvNtCsgWNsSMoiGk0_14chinese_ime_lm14safe_dot_probe13candidate_dot>:
100031980: 92400868    	and	x8, x3, #0x7
100031984: d343fc29    	lsr	x9, x1, #3
100031988: d343fc6a    	lsr	x10, x3, #3
10003198c: eb09015f    	cmp	x10, x9
100031990: 9a893149    	csel	x9, x10, x9, lo
100031994: b40002c9    	cbz	x9, 0x1000319ec <__RNvNtCsgWNsSMoiGk0_14chinese_ime_lm14safe_dot_probe13candidate_dot+0x6c>
100031998: 9100400a    	add	x10, x0, #0x10
10003199c: 9100104b    	add	x11, x2, #0x4
1000319a0: 6f00e400    	movi.2d	v0, #0000000000000000
1000319a4: b000052c    	adrp	x12, 0x1000d6000 <GCC_except_table571>
1000319a8: 3dc29182    	ldr	q2, [x12, #0xa40]
1000319ac: 6f00e401    	movi.2d	v1, #0000000000000000
1000319b0: ad7f9143    	ldp	q3, q4, [x10, #-0x10]
1000319b4: 2d7f9965    	ldp	s5, s6, [x11, #-0x4]
1000319b8: 4e0200a5    	tbl.16b	v5, { v5 }, v2
1000319bc: 4f28e4a5    	scvtf.4s	v5, v5, #0x18
1000319c0: 4e0200c6    	tbl.16b	v6, { v6 }, v2
1000319c4: 4f28e4c6    	scvtf.4s	v6, v6, #0x18
1000319c8: 6e25dc63    	fmul.4s	v3, v3, v5
1000319cc: 6e26dc84    	fmul.4s	v4, v4, v6
1000319d0: 4e23d421    	fadd.4s	v1, v1, v3
1000319d4: 4e24d400    	fadd.4s	v0, v0, v4
1000319d8: 9100814a    	add	x10, x10, #0x20
1000319dc: 9100216b    	add	x11, x11, #0x8
1000319e0: f1000529    	subs	x9, x9, #0x1
1000319e4: 54fffe61    	b.ne	0x1000319b0 <__RNvNtCsgWNsSMoiGk0_14chinese_ime_lm14safe_dot_probe13candidate_dot+0x30>
1000319e8: 14000003    	b	0x1000319f4 <__RNvNtCsgWNsSMoiGk0_14chinese_ime_lm14safe_dot_probe13candidate_dot+0x74>
1000319ec: 6f00e401    	movi.2d	v1, #0000000000000000
1000319f0: 6f00e400    	movi.2d	v0, #0000000000000000
1000319f4: 4e0c0422    	dup.4s	v2, v1[1]
1000319f8: 4e140423    	dup.4s	v3, v1[2]
1000319fc: 4e22d422    	fadd.4s	v2, v1, v2
100031a00: 4e22d462    	fadd.4s	v2, v3, v2
100031a04: 4e1c0421    	dup.4s	v1, v1[3]
100031a08: 4e22d421    	fadd.4s	v1, v1, v2
100031a0c: 4e21d401    	fadd.4s	v1, v0, v1
100031a10: 4e0c0402    	dup.4s	v2, v0[1]
100031a14: 4e21d441    	fadd.4s	v1, v2, v1
100031a18: 4e140402    	dup.4s	v2, v0[2]
100031a1c: 4e21d441    	fadd.4s	v1, v2, v1
100031a20: 4e1c0400    	dup.4s	v0, v0[3]
100031a24: 4e21d400    	fadd.4s	v0, v0, v1
100031a28: 92400829    	and	x9, x1, #0x7
100031a2c: eb09011f    	cmp	x8, x9
100031a30: 9a893109    	csel	x9, x8, x9, lo
100031a34: b4000849    	cbz	x9, 0x100031b3c <__RNvNtCsgWNsSMoiGk0_14chinese_ime_lm14safe_dot_probe13candidate_dot+0x1bc>
100031a38: 927de428    	and	x8, x1, #0x1ffffffffffffff8
100031a3c: 927dec6a    	and	x10, x3, #0x7ffffffffffffff8
100031a40: 8b080808    	add	x8, x0, x8, lsl #2
100031a44: 8b0a004a    	add	x10, x2, x10
100031a48: 3d400141    	ldr	b1, [x10]
100031a4c: 0f08a421    	sshll.8h	v1, v1, #0x0
100031a50: 0f10a421    	sshll.4s	v1, v1, #0x0
100031a54: 5e21d821    	scvtf	s1, s1
100031a58: bd400102    	ldr	s2, [x8]
100031a5c: 1e210841    	fmul	s1, s2, s1
100031a60: 1e212800    	fadd	s0, s0, s1
100031a64: f100053f    	cmp	x9, #0x1
100031a68: 540006a0    	b.eq	0x100031b3c <__RNvNtCsgWNsSMoiGk0_14chinese_ime_lm14safe_dot_probe13candidate_dot+0x1bc>
100031a6c: 3d400541    	ldr	b1, [x10, #0x1]
100031a70: 0f08a421    	sshll.8h	v1, v1, #0x0
100031a74: 0f10a421    	sshll.4s	v1, v1, #0x0
100031a78: 5e21d821    	scvtf	s1, s1
100031a7c: bd400502    	ldr	s2, [x8, #0x4]
100031a80: 1e210841    	fmul	s1, s2, s1
100031a84: 1e212800    	fadd	s0, s0, s1
100031a88: f100093f    	cmp	x9, #0x2
100031a8c: 54000580    	b.eq	0x100031b3c <__RNvNtCsgWNsSMoiGk0_14chinese_ime_lm14safe_dot_probe13candidate_dot+0x1bc>
100031a90: 3d400941    	ldr	b1, [x10, #0x2]
100031a94: 0f08a421    	sshll.8h	v1, v1, #0x0
100031a98: 0f10a421    	sshll.4s	v1, v1, #0x0
100031a9c: 5e21d821    	scvtf	s1, s1
100031aa0: bd400902    	ldr	s2, [x8, #0x8]
100031aa4: 1e210841    	fmul	s1, s2, s1
100031aa8: 1e212800    	fadd	s0, s0, s1
100031aac: f1000d3f    	cmp	x9, #0x3
100031ab0: 54000460    	b.eq	0x100031b3c <__RNvNtCsgWNsSMoiGk0_14chinese_ime_lm14safe_dot_probe13candidate_dot+0x1bc>
100031ab4: 3d400d41    	ldr	b1, [x10, #0x3]
100031ab8: 0f08a421    	sshll.8h	v1, v1, #0x0
100031abc: 0f10a421    	sshll.4s	v1, v1, #0x0
100031ac0: 5e21d821    	scvtf	s1, s1
100031ac4: bd400d02    	ldr	s2, [x8, #0xc]
100031ac8: 1e210841    	fmul	s1, s2, s1
100031acc: 1e212800    	fadd	s0, s0, s1
100031ad0: f100113f    	cmp	x9, #0x4
100031ad4: 54000340    	b.eq	0x100031b3c <__RNvNtCsgWNsSMoiGk0_14chinese_ime_lm14safe_dot_probe13candidate_dot+0x1bc>
100031ad8: 3d401141    	ldr	b1, [x10, #0x4]
100031adc: 0f08a421    	sshll.8h	v1, v1, #0x0
100031ae0: 0f10a421    	sshll.4s	v1, v1, #0x0
100031ae4: 5e21d821    	scvtf	s1, s1
100031ae8: bd401102    	ldr	s2, [x8, #0x10]
100031aec: 1e210841    	fmul	s1, s2, s1
100031af0: 1e212800    	fadd	s0, s0, s1
100031af4: f100153f    	cmp	x9, #0x5
100031af8: 54000220    	b.eq	0x100031b3c <__RNvNtCsgWNsSMoiGk0_14chinese_ime_lm14safe_dot_probe13candidate_dot+0x1bc>
100031afc: 3d401541    	ldr	b1, [x10, #0x5]
100031b00: 0f08a421    	sshll.8h	v1, v1, #0x0
100031b04: 0f10a421    	sshll.4s	v1, v1, #0x0
100031b08: 5e21d821    	scvtf	s1, s1
100031b0c: bd401502    	ldr	s2, [x8, #0x14]
100031b10: 1e210841    	fmul	s1, s2, s1
100031b14: 1e212800    	fadd	s0, s0, s1
100031b18: f100193f    	cmp	x9, #0x6
100031b1c: 54000100    	b.eq	0x100031b3c <__RNvNtCsgWNsSMoiGk0_14chinese_ime_lm14safe_dot_probe13candidate_dot+0x1bc>
100031b20: 3d401941    	ldr	b1, [x10, #0x6]
100031b24: 0f08a421    	sshll.8h	v1, v1, #0x0
100031b28: 0f10a421    	sshll.4s	v1, v1, #0x0
100031b2c: 5e21d821    	scvtf	s1, s1
100031b30: bd401902    	ldr	s2, [x8, #0x18]
100031b34: 1e210841    	fmul	s1, s2, s1
100031b38: 1e212800    	fadd	s0, s0, s1
100031b3c: d65f03c0    	ret
