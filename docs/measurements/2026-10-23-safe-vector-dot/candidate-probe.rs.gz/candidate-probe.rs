use super::*;
use std::hint::black_box;
use std::time::Instant;

fn frozen_dot_i8(a: &[f32], b: &[i8]) -> f32 {
    const LANES: usize = 8;
    let mut partial = [0.0f32; LANES];
    let left = a.chunks_exact(LANES);
    let right = b.chunks_exact(LANES);
    let (tail_left, tail_right) = (left.remainder(), right.remainder());
    for (x, y) in left.zip(right) {
        for lane in 0..LANES {
            partial[lane] += x[lane] * f32::from(y[lane]);
        }
    }
    let mut total = partial.iter().sum::<f32>();
    for (x, y) in tail_left.iter().zip(tail_right) {
        total += x * f32::from(*y);
    }
    total
}

#[inline(never)]
fn candidate_dot(a: &[f32], b: &[i8]) -> f32 {
    let left = a.chunks_exact(8);
    let right = b.chunks_exact(8);
    let (tail_left, tail_right) = (left.remainder(), right.remainder());
    let mut partial = wide::f32x8::ZERO;
    for (x, y) in left.zip(right) {
        let x = wide::f32x8::new(x.try_into().expect("完整八元素输入块"));
        let y = wide::i32x8::from(y).round_float();
        partial += x * y;
    }
    let mut total = partial.to_array().iter().sum::<f32>();
    for (x, y) in tail_left.iter().zip(tail_right) {
        total += x * f32::from(*y);
    }
    total
}

#[inline(never)]
fn reference_dot(a: &[f32], b: &[i8]) -> f32 {
    frozen_dot_i8(a, b)
}

fn inputs(n: usize) -> Vec<f32> {
    let mut state = 0xa196_eb37u32;
    (0..n).map(|i| {
        state ^= state << 13;
        state ^= state >> 17;
        state ^= state << 5;
        f32::from_bits(((i as u32 % 2) << 31) | ((112 + (state >> 23) % 27) << 23) | (state & 0x007f_ffff))
    }).collect()
}

#[test]
fn unchanged_bits() {
    for len in [0, 1, 7, 8, 9, 15, 16, 17, 192, 768] {
        for extra_a in [0, 1, 7, 9] {
            for extra_b in [0, 1, 7, 9] {
                let mut a = inputs(len + extra_a);
                let b: Vec<i8> = (0..len + extra_b).map(|i| (i * 31 % 256) as u8 as i8).collect();
                assert_eq!(reference_dot(&a, &b).to_bits(), candidate_dot(&a, &b).to_bits());
                for exceptional in [-0.0, f32::INFINITY, f32::NEG_INFINITY, f32::NAN] {
                    for value in &mut a { *value = exceptional; }
                    assert_eq!(reference_dot(&a, &b).to_bits(), candidate_dot(&a, &b).to_bits());
                }
            }
        }
    }
}

type Dot = fn(&[f32], &[i8]) -> f32;
fn elapsed(f: Dot, a: &[f32], b: &[i8], width: usize, repeats: usize) -> f64 {
    let start = Instant::now();
    for _ in 0..repeats {
        for row in b.chunks_exact(width) {
            black_box(f(black_box(a), black_box(row)));
        }
    }
    start.elapsed().as_secs_f64()
}

#[test]
#[ignore = "独占运行完整点积行配对预算"]
fn kernel_budget() {
    let mut failures = Vec::new();
    for (width, rows) in [(192, 192), (192, 576), (192, 768), (768, 192), (192, 8192), (7, 3), (9, 7)] {
        let a = inputs(width);
        let b: Vec<i8> = (0..width * rows).map(|i| (i * 31 % 256) as u8 as i8).collect();
        let mut repeats = 1;
        while elapsed(reference_dot, &a, &b, width, repeats).min(elapsed(candidate_dot, &a, &b, width, repeats)) < 0.005 { repeats *= 2; }
        let mut ratios = Vec::new();
        for pair in 0..21 {
            let (old, new) = if pair % 2 == 0 {
                let old = elapsed(reference_dot, &a, &b, width, repeats);
                (old, elapsed(candidate_dot, &a, &b, width, repeats))
            } else {
                let new = elapsed(candidate_dot, &a, &b, width, repeats);
                (elapsed(reference_dot, &a, &b, width, repeats), new)
            };
            println!("sample width={width} rows={rows} pair={pair} repeats={repeats} old={old:.9} new={new:.9}");
            ratios.push(new / old);
        }
        ratios.sort_by(f64::total_cmp);
        let limit = if width == 192 { 0.90 } else { 1.05 };
        println!("result width={width} rows={rows} median={:.8} limit={limit}", ratios[10]);
        if ratios[10] >= limit { failures.push((width, rows, ratios[10])); }
    }
    assert!(failures.is_empty(), "点积预算失败：{failures:?}");
}
