
reference/target/release/deps/chinese_ime_lm-4e5346c28d9c73d2:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100004444 <__RNvCsgWNsSMoiGk0_14chinese_ime_lm6dot_i8>:
100004444: 92400868    	and	x8, x3, #0x7
100004448: d343fc29    	lsr	x9, x1, #3
10000444c: d343fc6a    	lsr	x10, x3, #3
100004450: eb09015f    	cmp	x10, x9
100004454: 9a893149    	csel	x9, x10, x9, lo
100004458: b40004e9    	cbz	x9, 0x1000044f4 <__RNvCsgWNsSMoiGk0_14chinese_ime_lm6dot_i8+0xb0>
10000445c: 6f00e400    	movi.2d	v0, #0000000000000000
100004460: d000068a    	adrp	x10, 0x1000d6000 <GCC_except_table528+0x40>
100004464: 3dc30142    	ldr	q2, [x10, #0xc00]
100004468: d000068a    	adrp	x10, 0x1000d6000 <GCC_except_table528+0x40>
10000446c: 3dc30543    	ldr	q3, [x10, #0xc10]
100004470: aa0203ea    	mov	x10, x2
100004474: aa0003eb    	mov	x11, x0
100004478: 6f00e401    	movi.2d	v1, #0000000000000000
10000447c: acc11165    	ldp	q5, q4, [x11], #0x20
100004480: fc408546    	ldr	d6, [x10], #0x8
100004484: 4e0200c7    	tbl.16b	v7, { v6 }, v2
100004488: 4e0300c6    	tbl.16b	v6, { v6 }, v3
10000448c: 4f28e4c6    	scvtf.4s	v6, v6, #0x18
100004490: 4f28e4e7    	scvtf.4s	v7, v7, #0x18
100004494: 6e27dca5    	fmul.4s	v5, v5, v7
100004498: 6e26dc84    	fmul.4s	v4, v4, v6
10000449c: 4e24d400    	fadd.4s	v0, v0, v4
1000044a0: 4e25d421    	fadd.4s	v1, v1, v5
1000044a4: f1000529    	subs	x9, x9, #0x1
1000044a8: 54fffea1    	b.ne	0x10000447c <__RNvCsgWNsSMoiGk0_14chinese_ime_lm6dot_i8+0x38>
1000044ac: 4e0c0422    	dup.4s	v2, v1[1]
1000044b0: 4e140423    	dup.4s	v3, v1[2]
1000044b4: 4e22d422    	fadd.4s	v2, v1, v2
1000044b8: 4e23d442    	fadd.4s	v2, v2, v3
1000044bc: 4e1c0421    	dup.4s	v1, v1[3]
1000044c0: 4e21d441    	fadd.4s	v1, v2, v1
1000044c4: 1e202821    	fadd	s1, s1, s0
1000044c8: 5e0c0402    	mov	s2, v0[1]
1000044cc: 1e222821    	fadd	s1, s1, s2
1000044d0: 5e140402    	mov	s2, v0[2]
1000044d4: 1e222821    	fadd	s1, s1, s2
1000044d8: 5e1c0400    	mov	s0, v0[3]
1000044dc: 1e202820    	fadd	s0, s1, s0
1000044e0: 92400829    	and	x9, x1, #0x7
1000044e4: eb09011f    	cmp	x8, x9
1000044e8: 9a893109    	csel	x9, x8, x9, lo
1000044ec: b50000e9    	cbnz	x9, 0x100004508 <__RNvCsgWNsSMoiGk0_14chinese_ime_lm6dot_i8+0xc4>
1000044f0: d65f03c0    	ret
1000044f4: 6f00e400    	movi.2d	v0, #0000000000000000
1000044f8: 92400829    	and	x9, x1, #0x7
1000044fc: eb09011f    	cmp	x8, x9
100004500: 9a893109    	csel	x9, x8, x9, lo
100004504: b4ffff69    	cbz	x9, 0x1000044f0 <__RNvCsgWNsSMoiGk0_14chinese_ime_lm6dot_i8+0xac>
100004508: 927de428    	and	x8, x1, #0x1ffffffffffffff8
10000450c: 927dec6a    	and	x10, x3, #0x7ffffffffffffff8
100004510: 8b080808    	add	x8, x0, x8, lsl #2
100004514: 8b0a004a    	add	x10, x2, x10
100004518: 3d400141    	ldr	b1, [x10]
10000451c: 0f08a421    	sshll.8h	v1, v1, #0x0
100004520: 0f10a421    	sshll.4s	v1, v1, #0x0
100004524: 5e21d821    	scvtf	s1, s1
100004528: bd400102    	ldr	s2, [x8]
10000452c: 1e210841    	fmul	s1, s2, s1
100004530: 1e212800    	fadd	s0, s0, s1
100004534: f100053f    	cmp	x9, #0x1
100004538: 54fffdc0    	b.eq	0x1000044f0 <__RNvCsgWNsSMoiGk0_14chinese_ime_lm6dot_i8+0xac>
10000453c: 3d400541    	ldr	b1, [x10, #0x1]
100004540: 0f08a421    	sshll.8h	v1, v1, #0x0
100004544: 0f10a421    	sshll.4s	v1, v1, #0x0
100004548: 5e21d821    	scvtf	s1, s1
10000454c: bd400502    	ldr	s2, [x8, #0x4]
100004550: 1e210841    	fmul	s1, s2, s1
100004554: 1e212800    	fadd	s0, s0, s1
100004558: f100093f    	cmp	x9, #0x2
10000455c: 54fffca0    	b.eq	0x1000044f0 <__RNvCsgWNsSMoiGk0_14chinese_ime_lm6dot_i8+0xac>
100004560: 3d400941    	ldr	b1, [x10, #0x2]
100004564: 0f08a421    	sshll.8h	v1, v1, #0x0
100004568: 0f10a421    	sshll.4s	v1, v1, #0x0
10000456c: 5e21d821    	scvtf	s1, s1
100004570: bd400902    	ldr	s2, [x8, #0x8]
100004574: 1e210841    	fmul	s1, s2, s1
100004578: 1e212800    	fadd	s0, s0, s1
10000457c: f1000d3f    	cmp	x9, #0x3
100004580: 54fffb80    	b.eq	0x1000044f0 <__RNvCsgWNsSMoiGk0_14chinese_ime_lm6dot_i8+0xac>
100004584: 3d400d41    	ldr	b1, [x10, #0x3]
100004588: 0f08a421    	sshll.8h	v1, v1, #0x0
10000458c: 0f10a421    	sshll.4s	v1, v1, #0x0
100004590: 5e21d821    	scvtf	s1, s1
100004594: bd400d02    	ldr	s2, [x8, #0xc]
100004598: 1e210841    	fmul	s1, s2, s1
10000459c: 1e212800    	fadd	s0, s0, s1
1000045a0: f100113f    	cmp	x9, #0x4
1000045a4: 54fffa60    	b.eq	0x1000044f0 <__RNvCsgWNsSMoiGk0_14chinese_ime_lm6dot_i8+0xac>
1000045a8: 3d401141    	ldr	b1, [x10, #0x4]
1000045ac: 0f08a421    	sshll.8h	v1, v1, #0x0
1000045b0: 0f10a421    	sshll.4s	v1, v1, #0x0
1000045b4: 5e21d821    	scvtf	s1, s1
1000045b8: bd401102    	ldr	s2, [x8, #0x10]
1000045bc: 1e210841    	fmul	s1, s2, s1
1000045c0: 1e212800    	fadd	s0, s0, s1
1000045c4: f100153f    	cmp	x9, #0x5
1000045c8: 54fff940    	b.eq	0x1000044f0 <__RNvCsgWNsSMoiGk0_14chinese_ime_lm6dot_i8+0xac>
1000045cc: 3d401541    	ldr	b1, [x10, #0x5]
1000045d0: 0f08a421    	sshll.8h	v1, v1, #0x0
1000045d4: 0f10a421    	sshll.4s	v1, v1, #0x0
1000045d8: 5e21d821    	scvtf	s1, s1
1000045dc: bd401502    	ldr	s2, [x8, #0x14]
1000045e0: 1e210841    	fmul	s1, s2, s1
1000045e4: 1e212800    	fadd	s0, s0, s1
1000045e8: f100193f    	cmp	x9, #0x6
1000045ec: 54fff820    	b.eq	0x1000044f0 <__RNvCsgWNsSMoiGk0_14chinese_ime_lm6dot_i8+0xac>
1000045f0: 3d401941    	ldr	b1, [x10, #0x6]
1000045f4: 0f08a421    	sshll.8h	v1, v1, #0x0
1000045f8: 0f10a421    	sshll.4s	v1, v1, #0x0
1000045fc: 5e21d821    	scvtf	s1, s1
100004600: bd401902    	ldr	s2, [x8, #0x18]
100004604: 1e210841    	fmul	s1, s2, s1
100004608: 1e212800    	fadd	s0, s0, s1
10000460c: d65f03c0    	ret
