from pathlib import Path
import subprocess, time, os, json, hashlib, argparse
parser=argparse.ArgumentParser()
parser.add_argument('label')
parser.add_argument('binary')
args=parser.parse_args()
folder=Path('reference/target/safe-dot-evidence')
binary=Path(args.binary).resolve()
points=[]
started=time.monotonic()
quiet=None
names_to_watch={'cargo','rustc','clang','clang++','cc1','cc1plus','swift-frontend','ld','ld64'}
while True:
    now=time.monotonic()
    names=[Path(line.strip()).name for line in subprocess.check_output(['ps','-axo','comm='],text=True).splitlines()]
    compilers={name:names.count(name) for name in names_to_watch if name in names}
    point={'elapsed':now-started,'load':list(os.getloadavg()),'compilers':compilers}
    points.append(point)
    if not compilers and point['load'][0] <= 10:
        quiet=now if quiet is None else quiet
        if now-quiet >= 30: break
    else: quiet=None
    if now-started >= 180:
        (folder/(args.label+'-run.json')).write_text(json.dumps({'preflight':points,'timed':False,'reason':'quiet_timeout'},indent=2)+'\n')
        print('没有满足连续 30 秒无编译且 load<=10 的条件，未计时')
        raise SystemExit(2)
    time.sleep(1)
with (folder/(args.label+'.log')).open('w') as output:
    child=subprocess.Popen([str(binary),'safe_dot_probe::kernel_budget','--exact','--ignored','--nocapture'],stdout=output,stderr=subprocess.STDOUT)
    monitor=[]
    while child.poll() is None:
        names=[Path(line.strip()).name for line in subprocess.check_output(['ps','-axo','comm='],text=True).splitlines()]
        monitor.append({'load':list(os.getloadavg()),'compilers':{name:names.count(name) for name in names_to_watch if name in names}})
        time.sleep(1)
(folder/(args.label+'-run.json')).write_text(json.dumps({'preflight':points,'timed':True,'monitor':monitor,'exit_code':child.returncode,'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest()},indent=2)+'\n')
print('完成',args.label,'退出码',child.returncode,'监测样本',len(monitor),'编译重叠',sum(bool(p['compilers']) for p in monitor))
